public class Body{
    //inst vars
    String body;
    //def constr
    public Body(){
	this.body=
	    "  | |  \n"+
	    "~[. .]~\n"+
	    " |_|_| \n"+
	    " |_|_| \n"+
	    " |_|_| \n"+
	    " () () \n"+
	    " () () \n"+
	    " <] [> \n";	
    }
    public String getBody(){return body;}
    public String toString(){return getBody();}
}


/*
  .-'-.                                     
  //(_I_)\                                   
  \\) (//                                   
  //   \                                     
  \ | /                                     
  \|/                                     
  //|\                                     
  \|/                                     
  //Y\
  */
