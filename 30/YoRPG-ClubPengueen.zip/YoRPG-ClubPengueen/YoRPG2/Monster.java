//Team Club Pengueen -- Janet Zhang, Kevin Hwang, Dorothy Ng
//APCS1 pd5
//HW29 -- Ye Olde Role Playing Game, Improved
//2015-11-12

public class Monster extends Character{
    
    public Monster(){ super( 150 , 20+(int)(Math.random()*45) , 20 , 1.0 ); }
}